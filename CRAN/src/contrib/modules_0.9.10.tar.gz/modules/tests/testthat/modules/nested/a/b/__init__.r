cat('a/b/__init__.r\n')
