cat('a/b/c/e.r\n')
