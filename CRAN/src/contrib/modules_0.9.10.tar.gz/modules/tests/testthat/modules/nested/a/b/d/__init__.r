cat('a/b/d/__init__.r\n')
