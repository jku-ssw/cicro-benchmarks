message('Loading module "', module_name(), '"')
message('Module path: "', basename(module_file()), '"')
