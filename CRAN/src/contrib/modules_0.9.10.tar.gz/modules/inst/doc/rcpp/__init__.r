Rcpp::sourceCpp(module_file('convolve.cpp'), env = environment())
